package controlleur;

public class Type_exam {
private int idetypxam;
private String type_exam;

public Type_exam(int idetypxam, String type_exam) {
	super();
	this.idetypxam = idetypxam;
	this.type_exam = type_exam;
}

public Type_exam( String type_exam) {
	super();
	this.idetypxam = 0;
	this.type_exam = type_exam;
}
public int getIdetypxam() {
	return idetypxam;
}
public void setIdetypxam(int idetypxam) {
	this.idetypxam = idetypxam;
}
public String getType_exam() {
	return type_exam;
}
public void setType_exam(String type_exam) {
	this.type_exam = type_exam;
}

}