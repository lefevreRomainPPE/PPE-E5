package controlleur;

import vue.VueConnexion;
import vue.VueGenerale;


public class AutoEcoleCastellane {
    private static VueConnexion uneVueConnexion ;
    private static VueGenerale uneVueGenerale ;  
    
    public static void rendreVisibleVueConnexion(boolean action)
    {
    	uneVueConnexion.setVisible(action);
    }
    public static void rendreVisibleVueGenerale(boolean action,User unUser) {
    	if (action == true) {
    		uneVueGenerale = new VueGenerale(unUser);
    		uneVueGenerale.setVisible(true);
    	}else {
    		uneVueGenerale.dispose();
    	}
    }
	public static void main(String[] args) {
		
		uneVueConnexion = new VueConnexion();
		
	}

}
