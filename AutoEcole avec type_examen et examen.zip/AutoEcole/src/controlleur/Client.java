package controlleur;

public class Client {
private int n_client;
private String nom_client,prenom_client,adresse_client,adresse_mail,date_de_naissance,telephone,date_inscription,mode_facturation;
public Client(int n_client, String prenom_client, String nom_client, String adresse_client,String adresse_mail, String date_de_naissance, String telephone, String date_inscription, String mode_facturation) {
	super();
	this.n_client = n_client;
	this.nom_client = nom_client;
	this.prenom_client = prenom_client;
	this.adresse_client = adresse_client;
	this.adresse_mail = adresse_mail;
	this.date_de_naissance= date_de_naissance;
	this.telephone= telephone;
	this.date_inscription = date_inscription;
	this.mode_facturation = mode_facturation;
}
public Client(String prenom_client, String nom_client, String adresse_client,String adresse_mail, String date_de_naissance, String telephone, String date_inscription, String mode_facturation) {
	super();
	this.n_client = 0;
	this.nom_client = nom_client;
	this.prenom_client = prenom_client;
	this.adresse_client = adresse_client;
	this.adresse_mail= adresse_mail;
	this.date_de_naissance= date_de_naissance;
	this.telephone= telephone;
	this.date_inscription = date_inscription;
	this.mode_facturation = mode_facturation;
}

public int getN_client() {
	return n_client;
}
public void setN_client(int n_client) {
	this.n_client = n_client;
}
public String getNom_client() {
	return nom_client;
}
public void setNom_client(String nom_client) {
	this.nom_client = nom_client;
}
public String getPrenom_client() {
	return prenom_client;
}
public void setPrenom_client(String prenom_client) {
	this.prenom_client = prenom_client;
}
public String getAdresse_client() {
	return adresse_client;
}
public void setAdresse_client(String adresse_client) {
	this.adresse_client = adresse_client;
}
public String getAdresse_mail() {
	return adresse_mail;
}
public void setAdresse_mail(String adresse_mail) {
	this.adresse_mail = adresse_mail;
}
public String getDate_de_naissance() {
	return date_de_naissance;
}
public void setDate_de_naissance(String date_de_naissance) {
	this.date_de_naissance = date_de_naissance;
}
public String getTelephone() {
	return telephone;
}
public void setTelephone(String telephone) {
	this.telephone = telephone;
}
public String getDate_inscription() {
	return date_inscription;
}
public void setDate_inscription(String date_inscription) {
	this.date_inscription = date_inscription;
}
public String getMode_facturation() {
	return mode_facturation;
}
public void setMode_facturation(String mode_facturation) {
	this.mode_facturation = mode_facturation;
}
}