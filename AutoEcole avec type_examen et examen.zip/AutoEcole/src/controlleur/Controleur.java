package controlleur;

import java.util.ArrayList;

import modele.Modele;

public class Controleur {
public static User selectWhereUser (String email,String mdp) {
	return Modele.selectWhereUser(email,mdp);
}

public static void updateUser(User unUser) {
	Modele.updateUser (unUser);
	
}
/******************************Gestion des client*******************************/
public static void insertClient (Client unClient) {
	Modele.insertClient(unClient) ;
}
	public static ArrayList<Client> selectAllClients (String filtre){
	 return Modele.selectAllClients(filtre);
	 }

	public static Client selectWhereClient(String nom_client, String prenom_client, String adresse_client,String adresse_mail,String date_de_naissance, String telephone, String date_inscription, String mode_facturation) {
		return Modele.selectWhereClient(nom_client,prenom_client,adresse_client,adresse_mail,date_de_naissance,telephone,date_inscription,mode_facturation);
	}
	public static void deleteClient (int N_client) {
		Modele.deleteClient(N_client);
	}
	public static void updateClient (Client unClient) {
		Modele.updateClient(unClient);
	}

	


/******************************Gestion des moniteurs*******************************/

public static void insertMoniteur(Moniteur unMoniteur) {
    Modele.insertMoniteur(unMoniteur);	
}

	public static ArrayList<Moniteur> selectAllMoniteurs (String filtre){
	 return Modele.selectAllMoniteurs(filtre);
	 }

	public static Moniteur selectWhereMonieur(String nom_moniteur, String prenom_moniteur, String adresse_moniteur, String telephone) {
		return Modele.selectWhereMoniteur(nom_moniteur,prenom_moniteur,adresse_moniteur,telephone);
	}
	public static void deleteMoniteur (int N_moniteur) {
		Modele.deleteMoniteur(N_moniteur);
	}
	public static void updateMoniteur (Moniteur unMoniteur) {
		Modele.updateMoniteur(unMoniteur);
	}

/******************************Gestion des voitures*******************************/


public static void insertVoiture(Voiture uneVoiture) {
	Modele.insertVoiture(uneVoiture);	
}
public static ArrayList<Voiture> selectAllVoitures (String filtre){
	 return Modele.selectAllVoitures(filtre);
	 }
public static Voiture selectWhereVoiture(String immatriculation, String modele_voiture, String annee_modele) {
	return Modele.selectWhereVoiture(immatriculation,modele_voiture,annee_modele);
}
public static void deleteVoiture (int N_voiture) {
	Modele.deleteVoiture(N_voiture);
}
public static void updateVoiture (Voiture uneVoiture) {
	Modele.updateVoiture(uneVoiture);
}
/******************************Gestion des type d'examen*******************************/
public static void insertType_exam(Type_exam unType_exam) {
	Modele.insertType_exam(unType_exam);
}
public static ArrayList<Type_exam> selectAllType_exams(String filtre){
	 return Modele.selectAllType_exam(filtre);
	 }

	public static Type_exam selectWhereExam(String idetypxam, String type_exam) {
		return Modele.selectWhereType_exam(idetypxam,type_exam);
	}
	public static void deleteType_exam(int idetypxam) {
		Modele.deleteType_exam(idetypxam);
	}
	public static void updateType_exam(Type_exam unType_examen) {
		Modele.updateType_exam(unType_examen);
	}

	

/******************************Gestion des cours*******************************/

public static void insertCours(Cours unCours) {
	 Modele.insertCours(unCours);		
}
public static ArrayList<Cours> selectAllCours (String filtre){
	 return Modele.selectAllCours(filtre);
	 }

	public static Cours selectWhereCours(String n_client, String n_moniteur, String n_voiture, String date_heure_debut, String date_heure_fin) {
		return Modele.selectWhereCours(n_client,n_moniteur,n_voiture,date_heure_debut,date_heure_fin);
	}
	public static void deleteCours (int Id_client) {
		Modele.deleteClient(Id_client);
	}
	public static void updateCours (Client unCours) {
		Modele.updateClient(unCours);
	}

	


/*********************************Gestion des examens**********************************************/
	public static void insertExamen(Examen unExamen) {
		 Modele.insertExamen(unExamen);		
	}
	public static ArrayList<Examen> selectAllExamens (String filtre){
		 return Modele.selectAllExamen(filtre);
		 }

		public static Examen selectWhereExamen(String n_client, String n_moniteur, String n_voiture, String type_exam, String date_exam) {
			return Modele.selectWhereExamen(n_client,n_moniteur,n_voiture,type_exam,date_exam);
		}
		public static void deleteExamen (int Idexam) {
			Modele.deleteExamen(Idexam);
		}
		public static void updateExamen (Examen unExamen) {
			Modele.updateExamen(unExamen);
		}




}
