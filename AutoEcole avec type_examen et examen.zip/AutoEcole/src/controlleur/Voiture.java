package controlleur;

public class Voiture {
private int n_voiture;
private String immatriculation,modele_voiture,annee_modele;
public Voiture(int n_voiture, String immatriculation, String modele_voiture, String annee_modele) {
	super();
	this.n_voiture = n_voiture;
	this.immatriculation = immatriculation;
	this.modele_voiture = modele_voiture;
	this.annee_modele =annee_modele;
}
public Voiture( String immatriculation, String modele_voiture, String annee_modele) {
	super();
	this.n_voiture = 0;
	this.immatriculation = immatriculation;
	this.modele_voiture = modele_voiture;
	this.annee_modele =annee_modele;
}
public int getN_voiture() {
	return n_voiture;
}
public void setN_voiture(int n_voiture) {
	this.n_voiture = n_voiture;
}
public String getImmatriculation() {
	return immatriculation;
}
public void setImmatriculation(String immatriculation) {
	this.immatriculation = immatriculation;
}
public String getModele_voiture() {
	return modele_voiture;
}
public void setModele_voiture(String modele_voiture) {
	this.modele_voiture = modele_voiture;
}
public String getAnnee_modele() {
	return annee_modele;
}
public void setAnnee_modele(String annee_modele) {
	this.annee_modele = annee_modele;
}


}