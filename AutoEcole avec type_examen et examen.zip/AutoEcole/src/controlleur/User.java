package controlleur;

public class User{
private int iduser;
private String nom,prenom,email,mdp,role_enum ;
public User(int iduser, String nom, String prenom,String email,String mdp, String role_enum) {
	super();
	this.iduser = iduser;
	this.nom=nom;
	this.prenom=prenom;
	this.email=email;
	this.mdp =mdp;
	this.role_enum =role_enum;
}
public User( String nom,String prenom,String email, String mdp, String role_enum) {
	super();
	this.iduser = 0;
	this.nom=nom;
	this.prenom=prenom;
	this.email=email;
	this.mdp =mdp;
	this.role_enum =role_enum;
}
public int getIduser() {
	return iduser;
}
public void setIduser(int iduser) {
	this.iduser = iduser;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getPrenom() {
	return prenom;
}
public void setPrenom(String prenom) {
	this.prenom = prenom;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMdp() {
	return mdp;
}
public void setMdp(String mdp) {
	this.mdp = mdp;
}
public String getRole_enum() {
	return role_enum;
}
public void setRole_enum(String role_enum) {
	this.role_enum = role_enum;
}


}