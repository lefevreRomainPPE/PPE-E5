package controlleur;

public class Cours {
private int id_cours;
private int n_client,n_moniteur,n_voiture; 
private String date_heure_debut,date_heure_fin;
public Cours(int id_cours, int n_client,int n_moniteur, int n_voiture, String date_heure_debut,String date_heure_fin) {
	super();
	this.id_cours = id_cours;
	this.n_client = n_client;
	this.n_moniteur = n_moniteur;
	this.n_voiture = n_voiture;
	this.date_heure_debut= date_heure_debut;
	this.date_heure_fin=date_heure_fin;
}
public Cours( int n_client,int n_moniteur, int n_voiture, String date_heure_debut,String date_heure_fin) {
	super();
	this.id_cours = 0;
	this.n_client = n_client;
	this.n_moniteur = n_moniteur;
	this.n_voiture = n_voiture;
	this.date_heure_debut= date_heure_debut;
	this.date_heure_fin=date_heure_fin;
}
public int getId_cours() {
	return id_cours;
}
public void setId_cours(int id_cours) {
	this.id_cours = id_cours;
}
public int getN_client() {
	return n_client;
}
public void setN_client(int n_client) {
	this.n_client = n_client;
}
public int getN_moniteur() {
	return n_moniteur;
}
public void setN_moniteur(int n_moniteur) {
	this.n_moniteur = n_moniteur;
}
public int getN_voiture() {
	return n_voiture;
}
public void setN_voiture(int n_voiture) {
	this.n_voiture = n_voiture;
}
public String getDate_heure_debut() {
	return date_heure_debut;
}
public void setDate_heure_debut(String date_heure_debut) {
	this.date_heure_debut = date_heure_debut;
}
public String getDate_heure_fin() {
	return date_heure_fin;
}
public void setDate_heure_fin(String date_heure_fin) {
	this.date_heure_fin = date_heure_fin;
}

}