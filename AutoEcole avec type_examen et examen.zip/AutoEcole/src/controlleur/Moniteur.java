package controlleur;

public class Moniteur {
private int n_moniteur;
private String nom_moniteur,prenom_moniteur,adresse_moniteur,telephone/*nblecon*/;
public Moniteur(int n_moniteur, String nom_moniteur, String prenom_moniteur, String adresse_moniteur, String telephone/*String nblecon*/) {
	super();
	this.n_moniteur = n_moniteur;
	this.nom_moniteur = nom_moniteur;
	this.prenom_moniteur = prenom_moniteur;
	this.adresse_moniteur = adresse_moniteur;
	this.telephone= telephone;
	/*this.nblecon= nblecon;*/
}
public Moniteur(String nom_moniteur, String prenom_moniteur, String adresse_moniteur, String telephone/*String nblecon*/) {
	super();
	this.n_moniteur = 0;
	this.nom_moniteur = nom_moniteur;
	this.prenom_moniteur= prenom_moniteur;
	this.adresse_moniteur = adresse_moniteur;
	this.telephone= telephone;
	/*this.nblecon = nblecon ;*/ 
}
public int getN_moniteur() {
	return n_moniteur;
}
public void setN_moniteur(int n_moniteur) {
	this.n_moniteur = n_moniteur;
}
public String getNom_moniteur() {
	return nom_moniteur;
}
public void setNom_moniteur(String nom_moniteur) {
	this.nom_moniteur = nom_moniteur;
}
public String getPrenom_moniteur() {
	return prenom_moniteur;
}
public void setPrenom_moniteur(String prenom_moniteur) {
	this.prenom_moniteur = prenom_moniteur;
}
public String getAdresse_moniteur() {
	return adresse_moniteur;
}
public void setAdresse_moniteur(String adresse_moniteur) {
	this.adresse_moniteur = adresse_moniteur;
}
public String getTelephone() {
	return telephone;
}
public void setTelephone(String telephone) {
	this.telephone = telephone;
}
/*public String getNblecon() {
	return nblecon;
}
public void setNblecon(String nblecon) {
	this.nblecon = nblecon;
}
*/


}