package controlleur;

public class Examen {
private int idexam;
private int n_client,n_moniteur,n_voiture;
private String type_exam,date_exam;
public Examen(int idexam, int n_client, int n_moniteur, int n_voiture, String type_exam, String date_exam) {
	super();
	this.idexam = idexam;
	this.n_client = n_client;
	this.n_moniteur = n_moniteur;
	this.n_voiture = n_voiture;
	this.type_exam = type_exam;
	this.date_exam = date_exam;
}
public Examen( int n_client, int n_moniteur, int n_voiture, String type_exam, String date_exam) {
	super();
	this.idexam = 0;
	this.n_client = n_client;
	this.n_moniteur = n_moniteur;
	this.n_voiture = n_voiture;
	this.type_exam = type_exam;
	this.date_exam = date_exam;
}
public int getIdexam() {
	return idexam;
}
public void setIdexam(int idexam) {
	this.idexam = idexam;
}
public int getN_client() {
	return n_client;
}
public void setN_client(int n_client) {
	this.n_client = n_client;
}
public int getN_moniteur() {
	return n_moniteur;
}
public void setN_moniteur(int n_moniteur) {
	this.n_moniteur = n_moniteur;
}
public int getN_voiture() {
	return n_voiture;
}
public void setN_voiture(int n_voiture) {
	this.n_voiture = n_voiture;
}
public String getType_exam() {
	return type_exam;
}
public void setType_exam(String type_exam) {
	this.type_exam = type_exam;
}
public String getDate_exam() {
	return date_exam;
}
public void setDate_exam(String date_exam) {
	this.date_exam = date_exam;
}

}
