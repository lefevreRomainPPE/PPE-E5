package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import controlleur.AutoEcoleCastellane;
import controlleur.User;

public  class VueGenerale extends JFrame implements ActionListener
{
 private JPanel panelMenu= new JPanel();
 private JButton btProfil = new JButton("Profil");
 private JButton btClient = new JButton("Client");
 private JButton btCours = new JButton("Cours");
 private JButton btMoniteur = new JButton("Moniteur");
 private JButton btVoiture = new JButton("Voiture");
 private JButton btType_exam = new JButton("Type d'examen");
 private JButton btExamen = new JButton("Examen");
 private JButton btQuitter= new JButton("Quitter");
 //instanciation des panels
 private PanelProfil unPanelProfil ;
 private PanelClient unPanelClient= new PanelClient();
 private PanelCours unPanelCours= new PanelCours();
 private PanelMoniteur unPanelMoniteur= new PanelMoniteur();
 private PanelVoiutre unPanelVoiture= new PanelVoiutre();
private  PanelType_exam unPanelType_exam = new PanelType_exam();
private  PanelExamen unPanelExamen= new PanelExamen();

 public VueGenerale(User unUser) {
	 unPanelProfil= new PanelProfil(unUser);
	 this.setTitle("Auto Ecole Castellane");
	 this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 this.setResizable(false);
	 this.setLayout(null);
	 this.getContentPane().setBackground(Color.gray);
	 this.setBounds(100,100,1100,500);
	 
	 //construction du panel menu 
	 this.panelMenu.setBackground(Color.gray);
	 this.panelMenu.setBounds(80,10,920,30);
	 this.panelMenu.setLayout(new GridLayout(1,6));
	 this.panelMenu.add(this.btProfil);
	 this.panelMenu.add(this.btClient);
	 this.panelMenu.add(this.btCours);
	 this.panelMenu.add(this.btMoniteur);
	 this.panelMenu.add(this.btVoiture);
	 this.panelMenu.add(this.btType_exam);
	 this.panelMenu.add(this.btExamen);
	 this.panelMenu.add(this.btQuitter);
	 this.add(this.panelMenu);
	 //rendre les boutons ecoutables 
	 this.btProfil.addActionListener(this);
	 this.btClient.addActionListener(this);
	 this.btCours.addActionListener(this);
	 this.btMoniteur.addActionListener(this);
	 this.btVoiture.addActionListener(this);
	 this.btType_exam.addActionListener(this);
	 this.btExamen.addActionListener(this);
	 this.btQuitter.addActionListener(this);

	 //insertion des panels dans la fenêtre
	 this.add(this.unPanelProfil);
	 this.add(this.unPanelClient);
	 this.add(this.unPanelCours);
	 this.add(this.unPanelMoniteur);
	 this.add(this.unPanelVoiture);
	 this.add(this.unPanelType_exam);
	 this.add(this.unPanelExamen);
	 this.setVisible(true);
 }
 public void afficherPanel (int choix)
 {
	 this.unPanelProfil.setVisible(false);
	 this.unPanelClient.setVisible(false);
	 this.unPanelCours.setVisible(false);
	 this.unPanelMoniteur.setVisible(false);
	 this.unPanelVoiture.setVisible(false);
	 this.unPanelType_exam.setVisible(false);
	 this.unPanelExamen.setVisible(false);
	 switch(choix) {
	 case 1: this.unPanelProfil.setVisible(true);break;
	 case 2: this.unPanelClient.setVisible(true);break;
	 case 3: this.unPanelCours.setVisible(true);break;
	 case 4: this.unPanelMoniteur.setVisible(true);break;
	 case 5: this.unPanelVoiture.setVisible(true);break;
	 case 6: this.unPanelType_exam.setVisible(true);break;
	 case 7: this.unPanelExamen.setVisible(true);break;
	 }
 }
 
@Override
public void actionPerformed(ActionEvent e) {
	if (e.getSource()== this.btQuitter) {
		AutoEcoleCastellane.rendreVisibleVueGenerale(false, null);
		AutoEcoleCastellane.rendreVisibleVueConnexion(true);
	}
	else if (e.getSource()==this.btProfil) {
		this.afficherPanel(1);
	}
	else if (e.getSource()==this.btClient) {
		this.afficherPanel(2);
	}
	else if (e.getSource()==this.btCours) {
		this.afficherPanel(3);
	}
	else if (e.getSource()==this.btMoniteur) {
		this.afficherPanel(4);
	}
	else if (e.getSource()==this.btVoiture) {
		this.afficherPanel(5);
	}
	else if (e.getSource()==this.btType_exam) {
		this.afficherPanel(6);
	}
	else if (e.getSource()==this.btExamen) {
		this.afficherPanel(7);
	}
  }

}
