package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import controlleur.Client;
import controlleur.Controleur;
import controlleur.Tableau;

public class PanelClient extends PanelPrincipale implements ActionListener{
    private JPanel panelForm= new JPanel ();
    private JButton btAnnuler = new JButton("Annuler");
    private JButton btEnregistrer = new JButton("Enregistrer");
    private JTextField txtNom_client = new JTextField();
    private JTextField txtPrenom_client = new JTextField();
    private JTextField txtAdresse_client = new JTextField();
    private JTextField txtAdresse_mail= new JTextField();
    private JTextField txtDate_de_naissance = new JTextField();
    private JTextField txtTelephone = new JTextField();
    private JTextField txtDate_inscription = new JTextField();
    private JTextField txtMode_facturation = new JTextField();
    private JPanel panelListe = new JPanel();
    private JTable tableClients; 
	private JLabel lbTitre = new JLabel("Gestion des clients");
	private JLabel lbNbClient = new JLabel("Nombre de client : ");

    private JScrollPane uneScroll;
    
	private Tableau unTableau ; 

	
	private JPanel panelFiltre = new JPanel();
	private JTextField txtFiltre = new JTextField();
	private JButton btFiltrer =  new JButton("Filtrer");

    
	public PanelClient() {
		super("Gestion des clients ");
		//construire le nb classes
		this.lbNbClient.setBounds(300, 360, 400, 20);
		this.add(this.lbNbClient);
		//construire un titre
		this.lbTitre.setBounds(300 , 40, 200, 20);
		// construction du panel form : Insertion d'une classe
	  this.panelForm.setBounds(20,80,300,250);	
	  this.panelForm.setBackground(Color.gray);
	  this.panelForm.setLayout(new GridLayout(9,2));
	  this.panelForm.add(new JLabel("Nom du client :"));
	  this.panelForm.add(this.txtNom_client);
	  this.panelForm.add(new JLabel("Prenom du client :"));
	  this.panelForm.add(this.txtPrenom_client);
	  this.panelForm.add(new JLabel("Adresse du client:"));
	  this.panelForm.add(this.txtAdresse_client);
	  this.panelForm.add(new JLabel("Adresse mail:"));
	  this.panelForm.add(this.txtAdresse_mail);
	  this.panelForm.add(new JLabel("Date de naissance:"));
	  this.panelForm.add(this.txtDate_de_naissance);
	  this.panelForm.add(new JLabel("Telephone du client:"));
	  this.panelForm.add(this.txtTelephone);
	  this.panelForm.add(new JLabel("Date de l'inscription:"));
	  this.panelForm.add(this.txtDate_inscription);
	  this.panelForm.add(new JLabel("Mode de facturation:"));
	  this.panelForm.add(this.txtMode_facturation);
	  this.panelForm.add(this.btAnnuler);
	  this.panelForm.add(this.btEnregistrer);
	  
	  this.add(this.panelForm);
	  //construire le panel Liste 
	  this.panelListe.setBounds(370,130,660,200);	
	  this.panelListe.setBackground(Color.gray);
	  this.panelListe.setLayout(null);
	  String entetes [] = {"N_client" ,"Nom","Prenom", "Adresse","Adresse_mail","Dt_Nais", "Telephone","Dt_inscription","Mode_facturation"};
	  this.unTableau=new Tableau (this.ObtenirDonnees(""), entetes);
	  this.tableClients = new JTable(this.unTableau);
	  this.uneScroll = new JScrollPane(this.tableClients);
	  this.uneScroll.setBounds(0,0,660,200);
	  this.panelListe.add(this.uneScroll);
	  this.add(this.panelListe);
	  
	  //construction du pannel filtre
	  this.panelFiltre.setBackground(Color.gray);
	  this.panelFiltre.setBounds(370,90,460,30);
	  this.panelFiltre.setLayout(new GridLayout(1,3));
	  this.panelFiltre.add(new JLabel("Filtrer les classes :"));
	  this.panelFiltre.add(this.txtFiltre);
	  this.panelFiltre.add(this.btFiltrer);
	  this.add(this.panelFiltre);
	  
	  
	 //rendre les boutons ecoutables
	  this.btAnnuler.addActionListener(this);
	  this.btEnregistrer.addActionListener(this);
	//rendre la table non editable 
	  this.tableClients.getTableHeader().setReorderingAllowed(false);	
	//on affiche le nombre de classes
			this.lbNbClient.setText("Nombre de client : "+unTableau.getRowCount());
	  //mise en place de MousseListener sur la table 
	  this.tableClients.addMouseListener(new MouseListener() {
		  

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseClicked(MouseEvent e) {
			int numLigne = 0;
			int N_client = 0;
			if (e.getClickCount()>=2){
				numLigne = tableClients.getSelectedRow();
				N_client = Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
				int reponse = JOptionPane.showConfirmDialog(null,"Voulez-vous supprimer le client ? ",
						"Suppression de la classe", JOptionPane.YES_NO_OPTION);
				if (reponse ==0) {
					//supprression de la bdd
					Controleur.deleteClient(N_client);
					//actualisation de l'affichage
                  unTableau.supprimerLigne(numLigne);
					txtNom_client.setText("");
					txtPrenom_client.setText("");
					txtAdresse_client.setText("");
					txtAdresse_mail.setText("");
					txtDate_de_naissance.setText("");
					txtTelephone.setText("");
					txtDate_inscription.setText("");
					txtMode_facturation.setText("");
					btEnregistrer.setText("Enregistrer");
					//on affiche le nombre de classes
					lbNbClient.setText("Nombre de client : "+unTableau.getRowCount());
					//actualisation du CBX client dans la le panel cours
					PanelCours.remplirCBXClients();
				}	
			}else if(e.getClickCount()==1) {
				//remplir le champ du formulaire
				numLigne = tableClients.getSelectedRow();
				txtNom_client.setText(unTableau.getValueAt(numLigne,  1).toString());
				txtPrenom_client.setText(unTableau.getValueAt(numLigne,  2).toString());
				txtAdresse_client.setText(unTableau.getValueAt(numLigne,  3).toString());
				txtAdresse_mail.setText(unTableau.getValueAt(numLigne,  4).toString());
				txtDate_de_naissance.setText(unTableau.getValueAt(numLigne,  5).toString());
				txtTelephone.setText(unTableau.getValueAt(numLigne,  6).toString());
				txtMode_facturation.setText(unTableau.getValueAt(numLigne,  7).toString());

				btEnregistrer.setText("Modifier");
			}
		}
	});
}
	 public Object [][] ObtenirDonnees(String filtre ){
		 ArrayList <Client> lesClients = Controleur.selectAllClients(filtre);
		 Object [][] matrice = new Object [lesClients.size()][9];
		 int i=0;
		 for (Client unClient : lesClients) {
			 matrice[i][0]= unClient.getN_client();
			 matrice[i][1]= unClient.getNom_client();
			 matrice[i][2]= unClient.getPrenom_client();
			 matrice[i][3]= unClient.getAdresse_client();
			 matrice[i][4]= unClient.getAdresse_mail();
			 matrice[i][5]= unClient.getDate_de_naissance();
			 matrice[i][6]= unClient.getTelephone();
			 matrice[i][7]= unClient.getDate_inscription();
			 matrice[i][8]= unClient.getMode_facturation();

            i++ ;
		 }
		 return matrice;
	 }
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== this.btAnnuler) {
			this.txtNom_client.setText("");
			this.txtPrenom_client.setText("");
			this.txtAdresse_client.setText("");
			this.txtAdresse_mail.setText("");
			this.txtDate_de_naissance.setText("");
			this.txtTelephone.setText("");
			this.txtMode_facturation.setText("");



		}
		else if (e.getSource()== this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
			// recupèrer les champs
			String nom_client = this.txtNom_client.getText();
			String prenom_client = this.txtPrenom_client.getText();
			String adresse_client = this.txtAdresse_client.getText();
			String adresse_mail = this.txtAdresse_client.getText();
			String date_de_naissance = this.txtDate_de_naissance.getText();
			String telephone = this.txtTelephone.getText();
			String date_inscription = this.txtDate_inscription.getText();
			String mode_facturation = this.txtMode_facturation.getText();
			//on instancie une classe
			Client unClient = new Client (nom_client,prenom_client,adresse_client,adresse_mail,date_de_naissance,telephone,date_inscription,mode_facturation);
			// on insère dans la bdd
			Controleur.insertClient(unClient);
			
			
			
			//on vide les champs 
			this.txtNom_client.setText("");
			this.txtPrenom_client.setText("");
			this.txtAdresse_client.setText("");
			this.txtAdresse_mail.setText("");
			this.txtDate_de_naissance.setText("");
			this.txtTelephone.setText("");
			this.txtMode_facturation.setText("");
			
			  
			//on met à jour l'affichage 
			Object matrice [][] = this.ObtenirDonnees("");
			//on affiche le nombre de classes 
			this.lbNbClient.setText("Nombre de client : "+unTableau.getRowCount());
			//mis a jour de laffichege
			this.unTableau.setDonnees(matrice);
			JOptionPane.showMessageDialog(this," Insertion réussie dans la base de données");
			//actualisation du CBX classe dans la le panel etudiant
			PanelCours.remplirCBXClients();
		}
		else if(e.getSource() == this.btFiltrer) {
			String filtre = this.txtFiltre.getText();
			Object matrice [][] = this.ObtenirDonnees(filtre);
			//on affiche le nombre de classes 
			this.lbNbClient.setText("Nombre de client : "+unTableau.getRowCount());
			//mis a jour de laffichege
			this.unTableau.setDonnees(matrice);
		}
		else if(e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
			//recupere les champs
			String nom_client = this.txtNom_client.getText();
			String prenom_client = this.txtPrenom_client.getText();
			String adresse_client = this.txtAdresse_client.getText();
			String adresse_mail = this.txtAdresse_mail.getText();
			String date_de_naissance = this.txtDate_de_naissance.getText();
			String telephone = this.txtTelephone.getText();
			String date_inscription = this.txtTelephone.getText();
			String mode_facturation  = this.txtMode_facturation.getText();

			//on recupere idclasse de la table
			int numLigne = tableClients.getSelectedRow();
			int n_client = Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
			//on instancie une classe 
			Client unClient = new Client (nom_client,prenom_client,adresse_client,adresse_mail,date_de_naissance,telephone,date_inscription,mode_facturation);

			//on update dans la bdd
			Controleur.updateClient(unClient);
			//actualiser le tableau d'affichage
			Object ligne[] = {unClient.getN_client(),nom_client, prenom_client, adresse_client,adresse_mail,date_de_naissance,telephone,date_inscription,mode_facturation};
			this.unTableau.modifierLigne(numLigne, ligne);
			JOptionPane.showMessageDialog(this, "Modification effectué ");

			//on vide les champs
			this.txtNom_client.setText("");
			this.txtPrenom_client.setText("");
			this.txtAdresse_client.setText("");
			this.txtAdresse_mail.setText("");
			this.txtDate_de_naissance.setText("");
			this.txtTelephone.setText("");
			this.txtMode_facturation.setText("");
			this.btEnregistrer.setText("Enregistrer");
			//actualisation du CBX classe dans la le panel etudiant
			PanelCours.remplirCBXClients();
		}
	}
}

