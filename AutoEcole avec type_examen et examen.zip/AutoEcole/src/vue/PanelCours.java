package vue;
 
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
 
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controlleur.Client;
import controlleur.Controleur;
import controlleur.Cours;
import controlleur.Moniteur;
import controlleur.Voiture;



public class PanelCours extends PanelPrincipale implements ActionListener{
	private JPanel panelForm = new JPanel ();
	private JButton btAnnuler = new JButton("Annuler");
	private JButton btEnregistrer = new JButton("Enregistrer");
	
	private JTextField txtDate_heure_debut = new JTextField();
	private JTextField txtDate_heure_fin = new JTextField();

	private static JComboBox<String> txtN_Clients = new JComboBox<String>();
	private static JComboBox<String> txtN_moniteurs = new JComboBox<String>();
	private static JComboBox<String> txtN_voitures = new JComboBox<String>();

	
	
	public PanelCours() {
		super("Gestion des  cours ");
		//contruction du panel form : insertion d'un Cours
				this.panelForm.setBounds(20, 80, 300, 250);
				this.panelForm.setBackground(Color.gray);
				this.panelForm.setLayout(new GridLayout(6,2));
				 
				
				this.panelForm.add(new Label("Date heure debut "));
				this.panelForm.add(this.txtDate_heure_debut);
				
				
				this.panelForm.add(new Label("Date heure fin "));
				this.panelForm.add(this.txtDate_heure_fin);
				
				this.panelForm.add(new Label("l'id client"));
				this.panelForm.add(this.txtN_Clients);
				
				this.panelForm.add(new Label("l'id du moniteur"));
				this.panelForm.add(this.txtN_moniteurs);
				
				this.panelForm.add(new Label("l'id de la voiture"));
				this.panelForm.add(this.txtN_voitures);
				
				this.panelForm.add(this.btAnnuler);
				this.panelForm.add(this.btEnregistrer);
				
				this.add(this.panelForm);
				//remplir le CBX client
				this.remplirCBXClients ();
				//remplir le CBX client
				this.remplirCBXMoniteur ();
				
				//remplir le CBX voiture
				this.remplirCBXVoiture ();
				
				

				//rendre les boutons ecoutables
				this.btAnnuler.addActionListener(this);
				this.btEnregistrer.addActionListener(this);
	}
	public static void  remplirCBXClients () {
		ArrayList<Client> lesClients = Controleur.selectAllClients("");
		//vider le comBox des client
		txtN_Clients.removeAllItems();
		//on parcours les client et on insere les clients : id-nom
		
		for (Client unClient : lesClients) {
			txtN_Clients.addItem(unClient.getN_client()+"-"+unClient.getNom_client());
		}
	}
	public static void  remplirCBXMoniteur() {
		ArrayList<Moniteur> lesMoniteurs = Controleur.selectAllMoniteurs("");
		//vider le comBox des moniteurs
		txtN_moniteurs.removeAllItems();
		//on parcours les client et on insere les moniteur : id-nom
		
		for (Moniteur unMoniteur : lesMoniteurs) {
			txtN_moniteurs.addItem(unMoniteur.getN_moniteur()+"-"+unMoniteur.getNom_moniteur());
		}
	}
	public static void  remplirCBXVoiture() {
		ArrayList<Voiture> lesVoitures = Controleur.selectAllVoitures("");
		//vider le comBox des voiture
		txtN_voitures.removeAllItems();
		//on parcours les client et on insere les voitures : id-nom
		
		for (Voiture uneVoiture: lesVoitures) {
			txtN_voitures.addItem(uneVoiture.getN_voiture()+"-"+uneVoiture.getImmatriculation());
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.btAnnuler) {
			 
			this.txtDate_heure_debut.setText("");
			this.txtDate_heure_fin.setText("");

			}
		else if (e.getSource() == this.btEnregistrer) {
			//recupere les champs
			 
			String date_heure_debut = this.txtDate_heure_debut.getText();
			String date_heure_fin = this.txtDate_heure_fin.getText();

			//extraction de l'id du client  : id-nom
			String chaine = this.txtN_Clients.getSelectedItem().toString();
			String tab[] = chaine.split("-");
			int n_clients = Integer.parseInt(tab[0]);
			

			//extraction de l'id du moniteur  : id-nom
			 chaine = this.txtN_moniteurs.getSelectedItem().toString();
			String tab2[] = chaine.split("-");
			int n_moniteurs = Integer.parseInt(tab2[0]);
			
			//extraction de l'id de la voiture  : id-nom
			 chaine = this.txtN_voitures.getSelectedItem().toString();
			String tab3[] = chaine.split("-");
			int n_voitures = Integer.parseInt(tab3[0]);
			
			//instancie la classe cours
			Cours unCours = new Cours( n_clients,n_moniteurs,n_voitures,   date_heure_debut, date_heure_fin);
			
			//insertion dans la bdd
			Controleur.insertCours(unCours);
		}	
	}
 
}