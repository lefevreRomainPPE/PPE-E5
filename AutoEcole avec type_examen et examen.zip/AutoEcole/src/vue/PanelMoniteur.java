   package vue;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import controlleur.Client;
import controlleur.Controleur;
import controlleur.Moniteur;
import controlleur.Tableau;

public class PanelMoniteur extends PanelPrincipale implements ActionListener{
    private JPanel panelForm= new JPanel ();
    private JButton btAnnuler = new JButton("Annuler");
    private JButton btEnregistrer = new JButton("Enregistrer");
    private JTextField txtNom_moniteur = new JTextField();
    private JTextField txtPrenom_moniteur = new JTextField();
    private JTextField txtAdresse_moniteur= new JTextField();
    private JTextField txtTelephone = new JTextField();
    private JTextField txtNblecon= new JTextField();
    private JPanel panelListe = new JPanel();
    private JTable tableMoniteur; 
    private JScrollPane uneScroll;
    private JLabel lbTitre = new JLabel("Gestion des moniteurs");
	private JLabel lbNbMoniteur = new JLabel("Nombre de moniteur : ");
    private Tableau unTableau;
	
	private JPanel panelFiltre = new JPanel();
	private JTextField txtFiltre = new JTextField();
	private JButton btFiltrer =  new JButton("Filtrer");


    
	public PanelMoniteur() {
		super("Gestion des moniteurs ");
		//construire le nb moniteur
		this.lbNbMoniteur.setBounds(300, 360, 400, 20);
		this.add(this.lbNbMoniteur);
		// construction du panel form : Insertion d'un moniteur
	  this.panelForm.setBounds(20,80,300,250);	
	  this.panelForm.setBackground(Color.gray);
	  this.panelForm.setLayout(new GridLayout(6,1));
	  this.panelForm.add(new JLabel("Nom du moniteur :"));
	  this.panelForm.add(this.txtNom_moniteur);
	  this.panelForm.add(new JLabel("Prenom du moniteur:"));
	  this.panelForm.add(this.txtPrenom_moniteur);
	  this.panelForm.add(new JLabel("Adresse du moniteur:"));
	  this.panelForm.add(this.txtAdresse_moniteur);
	  this.panelForm.add(new JLabel("Telephone du moniteur:"));
	  this.panelForm.add(this.txtTelephone);
	  /*this.panelForm.add(new JLabel("nombre de lecon:"));
	  this.panelForm.add(this.txtNblecon);*/
	  this.panelForm.add(this.btAnnuler);
	  this.panelForm.add(this.btEnregistrer);
	  
	  this.add(this.panelForm);
	  
	//construire le panel Liste 
		this.panelListe.setBounds(370, 130, 460, 200);
		this.panelListe.setBackground(Color.gray);
		this.panelListe.setLayout(null);
		String entetes [] = {"N_moniteur", "Nom_moniteur", "Prenom_moniteur", "Adresse_moniteur","Telephone",/*"Nblecon"*/};
		

		this.unTableau = new Tableau (this.obtenirDonnees(""), entetes);
		this.tableMoniteur = new JTable(this.unTableau);
		
		this.uneScroll = new JScrollPane(this.tableMoniteur); 
		this.uneScroll.setBounds(0, 0, 460, 200);
		this.panelListe.add(this.uneScroll); 
		this.add(this.panelListe);
		
		//Construction du pannel filtre 
		this.panelFiltre.setBackground(Color.gray);
		this.panelFiltre.setBounds(370, 90, 460, 30);
		this.panelFiltre.setLayout(new GridLayout(1, 3));
		
		this.panelFiltre.add(new JLabel("Filtrer les cours :"));
		this.panelFiltre.add(this.txtFiltre); 
		this.panelFiltre.add(this.btFiltrer); 
		this.add(this.panelFiltre); 
	 //rendre les boutons ecoutables
	  this.btAnnuler.addActionListener(this);
	  this.btEnregistrer.addActionListener(this);
	//rendre la table non editable 
		this.tableMoniteur.getTableHeader().setReorderingAllowed(false);
		 this.tableMoniteur.getTableHeader().setReorderingAllowed(false);	
			//on affiche le nombre de moniteur
					this.lbNbMoniteur.setText("Nombre de moniteur : "+unTableau.getRowCount());
		//mise en place de MouseListener sur la table 
		this.tableMoniteur.addMouseListener(new MouseListener() {
			
			private int N_moniteur;

			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			public void mouseClicked(MouseEvent e) {
				int numLigne = 0; 
				int n_moniteur = 0; 
				if (e.getClickCount()>=2) {
					numLigne = tableMoniteur.getSelectedRow(); 
					n_moniteur = Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
					int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vous supprimer le moniteur ?", 
							"Suppression du  moniteur", JOptionPane.YES_NO_OPTION); 
					if (reponse == 0) {
						//suppression dans la BDD 
						Controleur.deleteMoniteur(N_moniteur);
						//actualisation de l'affichage 
						unTableau.supprimerLigne(numLigne);
						txtNom_moniteur.setText("");
						txtPrenom_moniteur.setText("");
						txtAdresse_moniteur.setText("");
						txtTelephone.setText("");
						btEnregistrer.setText("Enregistrer");
						//on affiche le nombre de moniteur
						lbNbMoniteur.setText("Nombre de moniteur : "+unTableau.getRowCount());
						//actualisation du CBX moniteur dans la le panel cours
						PanelCours.remplirCBXMoniteur();					}	
				}else if(e.getClickCount()==1) {
					//remplir le champ du formulaire
					numLigne = tableMoniteur.getSelectedRow();
					txtNom_moniteur.setText(unTableau.getValueAt(numLigne,  1).toString());
					txtPrenom_moniteur.setText(unTableau.getValueAt(numLigne,  2).toString());
					txtAdresse_moniteur.setText(unTableau.getValueAt(numLigne,  3).toString());
					txtTelephone.setText(unTableau.getValueAt(numLigne,  4).toString());
					/*txtNblecon.setText(unTableau.getValueAt(numLigne,  5).toString());*/

					btEnregistrer.setText("Modifier");
				}
			}
		});
	}
		
	public Object [][] obtenirDonnees (String filtre ){
		ArrayList <Moniteur> lesMoniteurs = Controleur.selectAllMoniteurs(filtre); 
		Object [][] matrice = new Object [lesMoniteurs.size()][5];
		int i = 0;
		for (Moniteur unMoniteur : lesMoniteurs) {
			matrice[i][0] = unMoniteur.getN_moniteur(); 
			matrice[i][1] = unMoniteur.getNom_moniteur(); 
			matrice[i][2] = unMoniteur.getPrenom_moniteur(); 
			matrice[i][3] = unMoniteur.getAdresse_moniteur(); 
			matrice[i][4] = unMoniteur.getTelephone();
			/*matrice[i][5] = unMoniteur.getNblecon();*/


			i ++ ;
		}
		return matrice;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== this.btAnnuler) {
			this.txtNom_moniteur.setText("");
			this.txtPrenom_moniteur.setText("");
			this.txtAdresse_moniteur.setText("");
			this.txtTelephone.setText("");
			/*this.txtNblecon.setText("");*/



		}
		else if (e.getSource()== this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
			// recupèrer les champs
			String nom_moniteur = this.txtNom_moniteur.getText();
			String prenom_moniteur = this.txtPrenom_moniteur.getText();
			String adresse_moniteur = this.txtAdresse_moniteur.getText();
			String telephone = this.txtTelephone.getText();	
			String nblecon =this.txtNblecon.getText();
			//on instancie une classe
			Moniteur unMoniteur = new Moniteur (nom_moniteur,prenom_moniteur,adresse_moniteur,telephone);
			// on insère dans la bdd
			Controleur.insertMoniteur(unMoniteur);
			//on vide les champs 
			this.txtNom_moniteur.setText("");
			this.txtPrenom_moniteur.setText("");
			this.txtAdresse_moniteur.setText("");
			this.txtTelephone.setText("");
			this.txtNblecon.setText("");
			
			//on met à jour l'affichage 
			 Object ligne[] = {unMoniteur.getN_moniteur(), nom_moniteur, prenom_moniteur,adresse_moniteur,telephone,nblecon};
			 this.unTableau.ajouterLigne(ligne);
			JOptionPane.showMessageDialog(this," Insertion réussie dans la base de données");
			//actualisation du CBX classe dans la le panel etudiant
			PanelCours.remplirCBXMoniteur();
		}
		else if(e.getSource() == this.btFiltrer) {
			String filtre = this.txtFiltre.getText();
			Object matrice [][] = this.obtenirDonnees(filtre);
			//on affiche le nombre de classes 
			this.lbNbMoniteur.setText("Nombre de moniteur : "+unTableau.getRowCount());
			//mis a jour de laffichege
			this.unTableau.setDonnees(matrice);
		}
		else if(e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
			//recupere les champs
			String nom_moniteur = this.txtNom_moniteur.getText();
			String prenom_moniteur = this.txtPrenom_moniteur.getText();
			String adresse_moniteur = this.txtAdresse_moniteur.getText();
			String telephone = this.txtTelephone.getText();
            /*String nblecon = this.txtNblecon.getText();*/
			//on recupere n_moniteur de la table
			int numLigne = tableMoniteur.getSelectedRow();
			int n_moniteur = Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
			//on instancie une classe 
			Moniteur unMoniteur = new Moniteur(nom_moniteur,prenom_moniteur,adresse_moniteur,telephone/*nblecon*/);

			//on update dans la bdd
			Controleur.updateMoniteur(unMoniteur);
			//actualiser le tableau d'affichage
			Object ligne[] = {unMoniteur.getN_moniteur(),nom_moniteur, prenom_moniteur, adresse_moniteur,telephone,/*nblecon*/};
			this.unTableau.modifierLigne(numLigne, ligne);
			JOptionPane.showMessageDialog(this, "Modification effectué ");

			//on vide les champs
			this.txtNom_moniteur.setText("");
			this.txtPrenom_moniteur.setText("");
			this.txtAdresse_moniteur.setText("");
			this.txtTelephone.setText("");
           /* this.txtNblecon.setText("");*/
			this.btEnregistrer.setText("Enregistrer");
			//actualisation du CBX classe dans la le panel etudiant
			PanelCours.remplirCBXMoniteur();
		}
	}

			
			
}