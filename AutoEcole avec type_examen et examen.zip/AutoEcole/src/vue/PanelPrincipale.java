package vue;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelPrincipale extends JPanel
{
public PanelPrincipale(String message) {
		this.setBackground(Color.gray);
		 this.setLayout(null);
		 this.setBounds(20,40,1060,400);
		 JLabel unTitre= new JLabel (message);
		 unTitre.setBounds(500,20,200,20);
		 this.add(unTitre);
		 
		 this.setVisible(false);
	 }
 }

