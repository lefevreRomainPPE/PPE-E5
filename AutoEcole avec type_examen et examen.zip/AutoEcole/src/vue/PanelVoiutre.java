package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import controlleur.Controleur;
import controlleur.Moniteur;
import controlleur.Tableau;
import controlleur.Voiture;

public class PanelVoiutre extends PanelPrincipale implements ActionListener{
	
	private JPanel panelForm= new JPanel ();
    private JButton btAnnuler = new JButton("Annuler");
    private JButton btEnregistrer = new JButton("Enregistrer");
    private JTextField txtImmatriculation = new JTextField();
    private JTextField txtModele_voiture= new JTextField();
    private JTextField txtAnnee_modele= new JTextField();
    private JPanel panelListe = new JPanel();
	  private JTable tableVoiture; 
	    private JScrollPane uneScroll;
	    private JLabel lbTitre = new JLabel("Gestion des voitures");
		private JLabel lbNbVoiture = new JLabel("Nombre de voiture : ");
	    private Tableau unTableau;
		
		private JPanel panelFiltre = new JPanel();
		private JTextField txtFiltre = new JTextField();
		private JButton btFiltrer =  new JButton("Filtrer");

    	
	public PanelVoiutre() {
		super("Gestion des voiture ");
		// construction du panel form : Insertion d'une classe
	  this.panelForm.setBounds(20,80,300,250);	
	  this.panelForm.setBackground(Color.gray);
	  this.panelForm.setLayout(new GridLayout(5,1));
	  this.panelForm.add(new JLabel("Immatriculation de la  voiture:"));
	  this.panelForm.add(this.txtImmatriculation);
	  this.panelForm.add(new JLabel("Modele de la voiture:"));
	  this.panelForm.add(this.txtModele_voiture);
	  this.panelForm.add(new JLabel("Annee modele de la voiture:"));
	  this.panelForm.add(this.txtAnnee_modele);
	  this.panelForm.add(this.btAnnuler);
	  this.panelForm.add(this.btEnregistrer);
	  
	  this.add(this.panelForm);
	  
		//construire le panel Liste 
			this.panelListe.setBounds(370, 130, 460, 200);
			this.panelListe.setBackground(Color.gray);
			this.panelListe.setLayout(null);
			String entetes [] = {"N_voiture", "immatriculation", "modele_voiture","annee_modele"};
			

			this.unTableau = new Tableau (this.obtenirDonnees(""), entetes);
			this.tableVoiture = new JTable(this.unTableau);
			
			this.uneScroll = new JScrollPane(this.tableVoiture); 
			this.uneScroll.setBounds(0, 0, 460, 200);
			this.panelListe.add(this.uneScroll); 
			this.add(this.panelListe);
			
			//Construction du pannel filtre 
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(370, 90, 460, 30);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			
			this.panelFiltre.add(new JLabel("Filtrer les cours :"));
			this.panelFiltre.add(this.txtFiltre); 
			this.panelFiltre.add(this.btFiltrer); 
			this.add(this.panelFiltre); 

	 //rendre les boutons ecoutables
	  this.btAnnuler.addActionListener(this);
	  this.btEnregistrer.addActionListener(this);
	//rendre la table non editable 
			this.tableVoiture.getTableHeader().setReorderingAllowed(false);
			//on affiche le nombre de moniteur
			this.lbNbVoiture.setText("Nombre de voiture : "+unTableau.getRowCount());
			//mise en place de MouseListener sur la table 
			this.tableVoiture.addMouseListener(new MouseListener() {
				
				private int N_voiture;

				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				public void mouseClicked(MouseEvent e) {
					int numLigne = 0; 
					int n_voiture= 0; 
					if (e.getClickCount()>=2) {
						numLigne = tableVoiture.getSelectedRow(); 
						n_voiture = Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
						int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vous supprimer la voiture ?", 
								"Suppression de la voiture", JOptionPane.YES_NO_OPTION); 
						if (reponse == 0) {
							//suppression dans la BDD 
							Controleur.deleteVoiture (N_voiture);
							//actualisation de l'affichage 
							unTableau.supprimerLigne(numLigne);
							txtImmatriculation.setText("");
							txtModele_voiture.setText("");
							txtAnnee_modele.setText("");
							btEnregistrer.setText("Enregistrer");
							//on affiche le nombre de moniteur
							lbNbVoiture.setText("Nombre de voiutre : "+unTableau.getRowCount());
							//actualisation du CBX moniteur dans la le panel cours
							PanelCours.remplirCBXVoiture();	
						}	
					}else if(e.getClickCount()==1) {
						//remplir le champ du formulaire
						numLigne = tableVoiture.getSelectedRow();
						txtImmatriculation.setText(unTableau.getValueAt(numLigne,  1).toString());
						txtModele_voiture.setText(unTableau.getValueAt(numLigne,  2).toString());
						txtAnnee_modele.setText(unTableau.getValueAt(numLigne,  3).toString());

						btEnregistrer.setText("Modifier");
						}
					}
					
				
			});

		}
		public Object [][] obtenirDonnees (String filtre ){
			ArrayList <Voiture> lesVoitures = Controleur.selectAllVoitures(filtre); 
			Object [][] matrice = new Object [lesVoitures.size()][4];
			int i = 0;
			for (Voiture uneVoiture : lesVoitures) {
				matrice[i][0] = uneVoiture.getN_voiture();
				matrice[i][1] = uneVoiture.getImmatriculation(); 
				matrice[i][2] = uneVoiture.getModele_voiture(); 
				matrice[i][3] = uneVoiture.getAnnee_modele(); 

				i ++ ;
			}
			return matrice;
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== this.btAnnuler) {
			this.txtImmatriculation.setText("");
			this.txtModele_voiture.setText("");
			this.txtAnnee_modele.setText("");



		}
		else if (e.getSource()== this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
			// recupèrer les champs
			String immatriculation = this.txtImmatriculation.getText();
			String modele_voiture = this.txtModele_voiture.getText();
			String annee_modele = this.txtAnnee_modele.getText();
			//on instancie une classe
			Voiture uneVoiture = new Voiture (immatriculation,modele_voiture,annee_modele);
			// on insère dans la bdd
			Controleur.insertVoiture(uneVoiture);
			//on vide les champs 
			this.txtImmatriculation.setText("");
			this.txtModele_voiture.setText("");
			this.txtAnnee_modele.setText("");
			
			uneVoiture = Controleur.selectWhereVoiture(immatriculation, modele_voiture, annee_modele);
			//on met à jour l'affichage 
			 Object ligne[] = {uneVoiture.getN_voiture(), immatriculation, modele_voiture,annee_modele};
			 this.unTableau.ajouterLigne(ligne);
			JOptionPane.showMessageDialog(this," Insertion réussie dans la base de données");
			//actualisation du CBX classe dans la le panel etudiant
			PanelCours.remplirCBXVoiture();
		}
		else if(e.getSource() == this.btFiltrer) {
			String filtre = this.txtFiltre.getText();
			Object matrice [][] = this.obtenirDonnees(filtre);
			//on affiche le nombre de classes 
			this.lbNbVoiture.setText("Nombre de moniteur : "+unTableau.getRowCount());
			//mis a jour de laffichege
			this.unTableau.setDonnees(matrice);
		}
		else if(e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
			//recupere les champs
			String immatriculation = this.txtImmatriculation.getText();
			String modele_voiture = this.txtModele_voiture.getText();
			String annee_modele = this.txtAnnee_modele.getText();

			//on recupere n_moniteur de la table
			int numLigne = tableVoiture.getSelectedRow();
			int n_moniteur = Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
			//on instancie une classe 
			Voiture uneVoiture= new Voiture(immatriculation,modele_voiture,annee_modele);

			//on update dans la bdd
			Controleur.updateVoiture(uneVoiture);
			//actualiser le tableau d'affichage
			Object ligne[] = {uneVoiture.getN_voiture(),immatriculation, modele_voiture, annee_modele};
			this.unTableau.modifierLigne(numLigne, ligne);
			JOptionPane.showMessageDialog(this, "Modification effectué ");

			//on vide les champs
			this.txtImmatriculation.setText("");
			this.txtModele_voiture.setText("");
			this.txtAnnee_modele.setText("");
			this.btEnregistrer.setText("Enregistrer");
			//actualisation du CBX classe dans la le panel etudiant
			PanelCours.remplirCBXVoiture();
		
		}
	}

			
			
}