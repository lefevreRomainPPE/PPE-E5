package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import controlleur.AutoEcoleCastellane;
import controlleur.Controleur;
import controlleur.User;

public class VueConnexion  extends JFrame implements ActionListener, KeyListener
{
	private JPanel panelConnexion1 = new JPanel();
	private JButton btAnnuler= new JButton("Annuler");
	private JButton BtSeConnecter= new JButton("Se Connecter");
	
	private JTextField txtEmail= new JTextField("a@gmail.com");
	private JPasswordField txtMdp= new JPasswordField("123");
  public VueConnexion () {
	  this.setTitle("Auto Ecole Castellane");
	  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  this.setResizable(false);
	  this.setLayout(null);
	  this.getContentPane().setBackground(Color.gray);
	  this.setBounds(100, 100, 600, 300);
	  // construction du panel de connexion 
	  this.panelConnexion1.setBounds(260,20,280,220);
	  this.panelConnexion1.setBackground(Color.gray);
	  this.panelConnexion1.setLayout( new GridLayout(3,2));
	  this.panelConnexion1.add(new JLabel("Email:"));
	  this.panelConnexion1.add(this.txtEmail);
	  this.panelConnexion1.add(new JLabel("MDP:"));
	  this.panelConnexion1.add(this.txtMdp);
	  this.panelConnexion1.add(this.btAnnuler);
	  this.panelConnexion1.add(this.BtSeConnecter);
	  this.add(this.panelConnexion1);

	  
	  
	  
	 //ajouter le logo
	  ImageIcon uneImage= new ImageIcon("src/images/Auto ecole castellane.png");
	  JLabel unLogo = new JLabel(uneImage);
	  unLogo.setBounds(20,20,220,220);
	  this.add(unLogo);
	  
	  //rendre les boutons ecoutables
	  this.btAnnuler.addActionListener(this);
	  this.BtSeConnecter.addActionListener(this);
	  //rendre les zones de textes ecoutables
	  this.txtEmail.addKeyListener(this);
	  this.txtMdp.addKeyListener(this);
	  
	  this.setVisible(true);
  }
  @Override
  public void actionPerformed(ActionEvent e) {
	  if(e.getSource()==this.btAnnuler) {
		  this.txtEmail.setText("");
	  }else if(e.getSource()==this.BtSeConnecter) {
		  this.traitement();
	  }
  }
  public void traitement () {
	  String email= this.txtEmail.getText();
	  String mdp=new String (this.txtMdp.getPassword());
	  
	  // on verifie la sécurité des données 
	  
	  // on verifie dans la BDD
	 User unUser = Controleur.selectWhereUser(email, mdp);
	  if(unUser !=null) {
		  JOptionPane.showMessageDialog(this, "Bienvenue M./MM"
            + unUser.getEmail());
		//on ouvre le logiciel
		  AutoEcoleCastellane.rendreVisibleVueConnexion(false);
		  AutoEcoleCastellane.rendreVisibleVueGenerale(true, unUser);
	  }else {
	  JOptionPane.showMessageDialog(this, "Veuillez vérifier vos identifiants");
  }
  }
@Override
public void keyTyped(KeyEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void keyPressed(KeyEvent e) {
if (e.getKeyCode()==KeyEvent.VK_ENTER) { // si on a appuyer sur la touche entrée
	this.traitement ();
}
	
}
@Override
public void keyReleased(KeyEvent e) {
	// TODO Auto-generated method stub
	
}
}
