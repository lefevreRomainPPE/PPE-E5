package vue;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
 
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controlleur.Client;
import controlleur.Controleur;
import controlleur.Cours;
import controlleur.Examen;
import controlleur.Moniteur;
import controlleur.Voiture;



public class PanelExamen extends PanelPrincipale implements ActionListener{
	private JPanel panelForm = new JPanel ();
	private JButton btAnnuler = new JButton("Annuler");
	private JButton btEnregistrer = new JButton("Enregistrer");
	
	private JTextField txtType_exam = new JTextField();
	private JTextField txtDate_exam = new JTextField();

	private static JComboBox<String> txtN_Clients = new JComboBox<String>();
	private static JComboBox<String> txtN_moniteurs = new JComboBox<String>();
	private static JComboBox<String> txtN_voitures = new JComboBox<String>();

	
	
	public PanelExamen() {
		super("Gestion des  examen ");
		//contruction du panel form : insertion d'un Examen
				this.panelForm.setBounds(20, 80, 300, 250);
				this.panelForm.setBackground(Color.gray);
				this.panelForm.setLayout(new GridLayout(6,2));
				 
				
				this.panelForm.add(new Label("le type de l'examen"));
				this.panelForm.add(this.txtType_exam);
				
				this.panelForm.add(new Label("la date de l'examen"));
				this.panelForm.add(this.txtDate_exam);
				
				this.panelForm.add(new Label("l'id client"));
				this.panelForm.add(this.txtN_Clients);
				
				this.panelForm.add(new Label("l'id du moniteur"));
				this.panelForm.add(this.txtN_moniteurs);
				
				this.panelForm.add(new Label("l'id de la voiture"));
				this.panelForm.add(this.txtN_voitures);
				
			
				
				this.panelForm.add(this.btAnnuler);
				this.panelForm.add(this.btEnregistrer);
				
				this.add(this.panelForm);
				//remplir le CBX client
				this.remplirCBXClients ();
				//remplir le CBX client
				this.remplirCBXMoniteur ();
				
				//remplir le CBX voiture
				this.remplirCBXVoiture ();
				
				

				//rendre les boutons ecoutables
				this.btAnnuler.addActionListener(this);
				this.btEnregistrer.addActionListener(this);
	}
	public static void  remplirCBXClients () {
		ArrayList<Client> lesClients = Controleur.selectAllClients("");
		//vider le comBox des client
		txtN_Clients.removeAllItems();
		//on parcours les client et on insere les clients : id-nom
		
		for (Client unClient : lesClients) {
			txtN_Clients.addItem(unClient.getN_client()+"-"+unClient.getNom_client());
		}
	}
	public static void  remplirCBXMoniteur() {
		ArrayList<Moniteur> lesMoniteurs = Controleur.selectAllMoniteurs("");
		//vider le comBox des moniteurs
		txtN_moniteurs.removeAllItems();
		//on parcours les client et on insere les moniteur : id-nom
		
		for (Moniteur unMoniteur : lesMoniteurs) {
			txtN_moniteurs.addItem(unMoniteur.getN_moniteur()+"-"+unMoniteur.getNom_moniteur());
		}
	}
	public static void  remplirCBXVoiture() {
		ArrayList<Voiture> lesVoitures = Controleur.selectAllVoitures("");
		//vider le comBox des voiture
		txtN_voitures.removeAllItems();
		//on parcours les client et on insere les voitures : id-nom
		
		for (Voiture uneVoiture: lesVoitures) {
			txtN_voitures.addItem(uneVoiture.getN_voiture()+"-"+uneVoiture.getImmatriculation());
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.btAnnuler) {
			 
			this.txtType_exam.setText("");
			this.txtDate_exam.setText("");

			}
		else if (e.getSource() == this.btEnregistrer) {
			//recupere les champs
			 
			String type_exam = this.txtType_exam.getText();
			String date_exam = this.txtDate_exam.getText();

			//extraction de l'id du client  : id-nom
			String chaine = this.txtN_Clients.getSelectedItem().toString();
			String tab[] = chaine.split("-");
			int n_clients = Integer.parseInt(tab[0]);
			

			//extraction de l'id du moniteur  : id-nom
			 chaine = this.txtN_moniteurs.getSelectedItem().toString();
			String tab2[] = chaine.split("-");
			int n_moniteurs = Integer.parseInt(tab2[0]);
			
			//extraction de l'id de la voiture  : id-nom
			 chaine = this.txtN_voitures.getSelectedItem().toString();
			String tab3[] = chaine.split("-");
			int n_voitures = Integer.parseInt(tab3[0]);
			
			//instancie la classe cours
			Examen unExamen = new Examen( n_clients,n_moniteurs,n_voitures,   type_exam, date_exam);
			
			//insertion dans la bdd
			Controleur.insertExamen(unExamen);
		}	
	}
 
}