package vue;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controlleur.User;
import controlleur.Controleur;

	

	public class PanelProfil extends PanelPrincipale implements ActionListener{
		

		private JPanel panelForm = new JPanel ();
		private JButton btAnnuler= new JButton("Annuler");
		private JButton btEnregistrer = new JButton("Enregistrer");
		private JTextField txtNom = new JTextField();
		private JTextField txtPrenom = new JTextField();
		private JTextField txtEmail = new JTextField();

		private JTextField txtRole_enum = new JTextField();
		private JPasswordField txtMdp = new JPasswordField();
		private User unUser; 
		private JButton btModifier = new JButton("Modifier");
		private JTextArea txtInfos = new JTextArea();

		public PanelProfil(User unUser) {
			super ("Gestion du Profil");
			
			this.unUser = unUser;
	// construction du panel form : modification du profil
	this.panelForm.setBounds(400, 80, 500,250);
	this.panelForm.setBackground(Color.gray);
	this.panelForm.setLayout(new GridLayout(6,2));
	this.panelForm.add(new JLabel("Nom: "));
	this.panelForm.add(this.txtNom);
	
	
	this.panelForm.add(new JLabel("Prénom : "));
	this.panelForm.add(this.txtPrenom);


	this.panelForm.add(new JLabel("Email: "));
	this.panelForm.add(this.txtEmail);

	this.panelForm.add(new JLabel("Mdp : "));
	this.panelForm.add(this.txtMdp);

	this.panelForm.add(new JLabel("Role_enum: "));
	this.panelForm.add(this.txtRole_enum);

    this.panelForm.add(this.btAnnuler);
    this.panelForm.add(this.btEnregistrer);
    
    this.add(this.panelForm);
    //construction de texteArea Infos

    this.txtInfos.setBounds(20,80,250,250);
    
		 
	 //construction de TexteArea Info
	 this.txtInfos.setBounds(20,40,250,250);
	 this.add(this.txtInfos);
	 this.txtInfos.setBackground(new Color(149,168,145 ));
	 this.txtInfos.setText(
	 "_________INFOS PROFIL______\n"
	 +"\n\n Nom :"+this.unUser.getNom()
	 +"\n\n Prenom :"+this.unUser.getPrenom()
	 +"\n\n Email :"+this.unUser.getEmail()
	 +"\n\n Role_enum:"+this.unUser.getRole_enum()
	);
	 this.btModifier.setBounds(80, 310, 100 ,30);
	 this.add(this.btModifier);
	 //rendre le formulaire non visible
	 this.panelForm.setVisible(false);
	 //rendre les boutons ecoutables
	 this.btModifier.addActionListener(this);		
	 this.btAnnuler.addActionListener(this);
	this.btEnregistrer.addActionListener(this);
}

@Override
public void actionPerformed(ActionEvent e) {
	 if(e.getSource()==this.btModifier) {
		 this.panelForm.setVisible(true);
		 this.txtNom.setText(unUser.getNom());
		 this.txtPrenom.setText(unUser.getPrenom());
		 
		 this.txtEmail.setText(unUser.getEmail());
		 if (unUser.getRole_enum().equals("user")) {
			 this.txtRole_enum.setEditable(false);
		 }
		 this.txtRole_enum.setText(unUser.getRole_enum());
		 this.txtMdp.setText(unUser.getMdp());

		 
	 }else if (e.getSource()== this.btAnnuler) {
		 this.panelForm.setVisible(false);
     }
	 else if (e.getSource()== this.btEnregistrer) {
		 
	     String nom = this.txtNom.getText();
	     String prenom = this.txtPrenom.getText();
	     String email = this.txtEmail.getText();
	     String role_enum = this.txtRole_enum.getText();
	     String mdp = new String (this.txtMdp.getPassword());

        //instancier un user 
	     this.unUser= new User(unUser.getIduser(),nom,prenom,email,mdp,role_enum);
	     
	     //réaliser la modification dans la BDD
		Controleur.updateUser(this.unUser);
	     
	     //actualiser l'affichage des données profil
		this.txtInfos.setText(

		 " _______ INFOS PROFIL________ \n"
			+"\n \n  Nom :" +this.unUser.getNom()
			+"\n \n  Prenom :" +this.unUser.getPrenom()
			+"\n \n  Email :" +this.unUser.getEmail()
			+"\n \n  Role :" +this.unUser.getRole_enum()
			);
		
		JOptionPane.showMessageDialog(this, "Modification réussie des infos du profil");
		
		this.panelForm.setVisible(false);
		}
 }
}