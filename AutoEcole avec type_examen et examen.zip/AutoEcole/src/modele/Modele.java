package modele;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import controlleur.Client;
import controlleur.Cours;
import controlleur.Examen;
import controlleur.Moniteur;
import controlleur.Type_exam;
import controlleur.User;
import controlleur.Voiture;

public class Modele {
private static Bdd uneBdd = new Bdd("localhost","castellane","root","");
private static String requete;

public static User selectWhereUser (String email, String mdp) {
	 User  unUser= null;
	String  requete="select*from user where email='"+email+"' and mdp ='"+mdp+"'";
	try {
		uneBdd.seConnecter();
		Statement unStat= uneBdd.getMaconnexion().createStatement(); //curseur d'execution
		//recupération de l'utilisateur
		ResultSet unRes= unStat.executeQuery(requete);
		if (unRes.next()) {
			unUser = new User (
					
					unRes.getInt("iduser"), unRes.getString("nom"),
					unRes.getString("prenom"), unRes.getString("email"),
					unRes.getString("mdp"), unRes.getString("role")
					);
				}
			
		
		unStat.close();
		uneBdd.seDeconnecter();
	}
	catch (SQLException exp) {
		System.out.println("Erreur d'execution: "+requete);
	}
	return unUser;
 }

public static void updateUser(User unUser) {
	 String requete="update user set nom='"
	 + unUser.getNom()+"',prenom='"
	 + unUser.getPrenom()+"',email='"
	 + unUser.getEmail()+" , role_enum='"
	 +unUser.getRole_enum()+"' ,mdp'"
	 + unUser.getMdp()+"' where iduser = " + unUser.getIduser()+";";
	 try {
	  uneBdd.seConnecter();
	  Statement unStat=uneBdd.getMaconnexion().createStatement();
	  unStat.execute(requete);
	  unStat.close();
	  uneBdd.seDeconnecter();
	 }
	 catch(SQLException exp) {
		 System.out.println("erreur execution requete :" + requete);
	 }
	 
}
/*****************************Gestion des clients****************************/
public static void insertClient (Client unClient) {
	String requete ="insert into client values (null,'"
			+unClient.getNom_client()+"','" + unClient.getPrenom_client()
			+"','"+unClient.getAdresse_client()+"','"+unClient.getAdresse_mail()+"','"+unClient.getDate_de_naissance()+"','"+unClient.getTelephone()+"','"+unClient.getDate_inscription()
			+"','"+unClient.getMode_facturation()+"');";
	 try {
		  uneBdd.seConnecter();
		  Statement unStat=uneBdd.getMaconnexion().createStatement();
		  unStat.execute(requete);
		  unStat.close();
		  uneBdd.seDeconnecter();
		 }
		 catch(SQLException exp) {
			 System.out.println("erreur execution requete :" + requete);
		 }
}
public static ArrayList<Client> selectAllClients (String filtre){
	String requete ="";
	if (filtre.equals("")) {
		requete ="select * from client ;";
	}else {
		requete = "select * from client where nom_client like '%"+filtre
				+"%' or prenom_client like '"+filtre +"%' or adresse_client like '%"+filtre
				+"%' or adresse_mail like '"+filtre
				+"%'or date_de_naissance like '"+filtre +"%' or telephone like '%"+filtre
				+"%'or date_insription like '"+filtre +"%' or mode_facturation like '%"+filtre+"%' ";
	}
	ArrayList<Client>lesClients = new ArrayList<Client>();
	try {
		 uneBdd.seConnecter();
		  Statement unStat=uneBdd.getMaconnexion().createStatement();
		  ResultSet desRes = unStat.executeQuery(requete);
		  // on parcours les resultat pour construire ArrayList
		  while (desRes.next()) {
			  Client unClient= new Client (
			  desRes.getInt("n_client"), desRes.getString("nom_client"),
			  desRes.getString("prenom_client"), desRes.getString("adresse_client"),desRes.getString("adresse_mail"),
			  desRes.getString("date_de_naissance"),desRes.getString("telephone"),
			  desRes.getString("date_inscription"), desRes.getString("mode_facturation")
			  
			  );
			lesClients.add(unClient);
		  }
		  unStat.close();
		  uneBdd.seDeconnecter();
	}
	catch (SQLException exp) {
		System.out.println("erreur execution requete: " + requete);
	}
	return lesClients;
 }  

public static Client selectWhereClient(String nom_client, String prenom_client, String adresse_client,String adresse_mail, String date_de_naissance, String telephone, String date_inscription, String mode_facturation) {
		String requete = "select * from client where nom_client='"+nom_client
				+"'and prenom_client='"+prenom_client+"' and adresse_client ='"+adresse_client+
				"' and adresse_mail ='"+adresse_mail+
				"' and date_de_naissance ='"+date_de_naissance+"' and telephone ='"+telephone+
				"' and date_inscription='"+date_inscription+"' and mode_facturation ='"+mode_facturation+"' ";
	 Client unClient = null;
		try {
			 uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  ResultSet desRes = unStat.executeQuery(requete);
			  // on parcours les resultat pour construire ArrayList
			  if (desRes.next()) {
				 unClient = new Client (
						  desRes.getInt("n_client"), desRes.getString("nom_client"),
						  desRes.getString("prenom_client"), desRes.getString("adresse_client"),
						  desRes.getString("adresse_mail"),
						  desRes.getString("date_de_naissance"),desRes.getString("telephone"),
						  desRes.getString("date_inscription"), desRes.getString("mode_facturation")
						  ) ;
						  
			  }
			  unStat.close();
			  uneBdd.seDeconnecter();
		}
		catch (SQLException exp) {
			System.out.println("erreur execution requete: " + requete);
		}
		return unClient;
	}
	public static void deleteClient (int N_client) {
		String requete= "delete from client where n_client = "+N_client+";";
		 try {
			  uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  unStat.execute(requete);
			  unStat.close();
			  uneBdd.seDeconnecter();
			 }
			 catch(SQLException exp) {
				 System.out.println("erreur execution requete :" + requete);
			 }
	}
	public static void updateClient (Client unClient) {
		String requete= "update classe "
				+ "set nom='"+unClient.getNom_client()+
				"', prenom_client='"+unClient.getPrenom_client()+
				"',adresse_client='"+unClient.getAdresse_client()+
				"',adresse_mail='"+unClient.getAdresse_mail()+
				"',date_de_naissance='"+unClient.getDate_de_naissance()+
				"',telephone"+unClient.getTelephone()+
				"',date_inscription='"+unClient.getTelephone()+
				"',mode_facturation='"+unClient.getMode_facturation()+


				"' where idclient ="+unClient.getN_client()+";";
		 try {
			  uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  unStat.execute(requete);
			  unStat.close();
			  uneBdd.seDeconnecter();
			 }
			 catch(SQLException exp) {
				 System.out.println("erreur execution requete :" + requete);
			 }
	}


	

/*****************************Gestion des Moniteurs****************************/

	 public static void insertMoniteur(Moniteur unMoniteur) { 

		String requete ="insert into moniteur values (null,'"
				+unMoniteur.getNom_moniteur()+"','" + unMoniteur.getPrenom_moniteur()
				+"','"+unMoniteur.getAdresse_moniteur()+"','"+unMoniteur.getTelephone()+"');";
		 try {
			  uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  unStat.execute(requete);
			  unStat.close();
			  uneBdd.seDeconnecter();
			 }
			 catch(SQLException exp) {
				 System.out.println("erreur execution requete :" + requete);
			 }
	 }
		 public static ArrayList<Moniteur> selectAllMoniteurs (String filtre){
		 String requete ="";
				if (filtre.equals("")) {
					requete ="select * from moniteur ;";
				}else {
					requete = "select * from moniteur where nom_moniteur like '%"+filtre
							+"%' or prenom_moniteur like '%"+filtre+"%' or adresse_moniteur like '%"+filtre
							+"%'or telephone like '%"+filtre+"%' " ;
				}  
				ArrayList<Moniteur>lesMoniteurs = new ArrayList<Moniteur>();
				try {
					 uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  ResultSet desRes = unStat.executeQuery(requete);
					  // on parcours les resultat pour construire ArrayList
					  while (desRes.next()) {
						  Moniteur unMoniteur= new Moniteur (
								  desRes.getInt("n_moniteur"), desRes.getString("nom_moniteur"), desRes.getString("prenom_moniteur"),
						  desRes.getString("adresse_moniteur"), desRes.getString("telephone")
						  );
						lesMoniteurs.add(unMoniteur);
					  }
					  unStat.close();
					  uneBdd.seDeconnecter();
				}
				catch (SQLException exp) {
					System.out.println("erreur execution requete: " + requete);
				}
				return lesMoniteurs;
			 }  

		 public static Moniteur selectWhereMoniteur(String nom_moniteur, String prenom_moniteur, String adresse_moniteur,
					String telephone) {
			
					String requete = "select * from cours where nom_moniteur='"+nom_moniteur+"'and prenom_moniteur='"+prenom_moniteur+"'and adressse_moniteur='"
					+adresse_moniteur+"'and telephone ='"+telephone+ "'  ";
				 Moniteur unMoniteur = null;
					try {
						 uneBdd.seConnecter();
						  Statement unStat=uneBdd.getMaconnexion().createStatement();
						  ResultSet desRes = unStat.executeQuery(requete);
						  // on parcours les resultat pour construire ArrayList
						  if (desRes.next()) {
							    unMoniteur= new Moniteur  (
									  desRes.getInt("n_moniteur"), desRes.getString("nom_moniteur"), desRes.getString("prenom_moniteur"),
							  desRes.getString("adresse_moniteur"), desRes.getString("telephone")
							  );		  
						  }
						  unStat.close();
						  uneBdd.seDeconnecter();
					}
					catch (SQLException exp) {
						System.out.println("erreur execution requete: " + requete);
					}
					return unMoniteur;
				}
			public static void deleteMoniteur(int n_moniteur) {
					String requete= "delete from cours where n_moniteur = "+n_moniteur+";" ; 
					 try {
						  uneBdd.seConnecter();
						  Statement unStat=uneBdd.getMaconnexion().createStatement();
						  unStat.execute(requete);
						  unStat.close();
						  uneBdd.seDeconnecter();
						 }
						 catch(SQLException exp) {
							 System.out.println("erreur execution requete :" + requete);
						 }
			}
	 
				public static void updateMoniteur (Moniteur unMoniteur) {
					String requete= "update moniteur "
							+ "set nom_moniteur='"+unMoniteur.getNom_moniteur()+
							"', prenom_moniteur='"+unMoniteur.getPrenom_moniteur()+
							"',adresse_moniteur='"+unMoniteur.getAdresse_moniteur()+
							"',telephone'"+unMoniteur.getTelephone()+
						


							"' where n_moniteur ="+unMoniteur.getN_moniteur()+";";
					 try {
						  uneBdd.seConnecter();
						  Statement unStat=uneBdd.getMaconnexion().createStatement();
						  unStat.execute(requete);
						  unStat.close();
						  uneBdd.seDeconnecter();
						 }
						 catch(SQLException exp) {
							 System.out.println("erreur execution requete :" + requete);
						 }
				
				
	 
				}
	 
	 /*****************************Gestion des voitures****************************/

	 public static void insertVoiture(Voiture uneVoiture) { 

			String requete ="insert into voiture values (null,'"
					+uneVoiture.getImmatriculation()+"','" + uneVoiture.getModele_voiture()
					+"','"+uneVoiture.getAnnee_modele()+"');";
			 try {
				  uneBdd.seConnecter();
				  Statement unStat=uneBdd.getMaconnexion().createStatement();
				  unStat.execute(requete);
				  unStat.close();
				  uneBdd.seDeconnecter();
				 }
				 catch(SQLException exp) {
					 System.out.println("erreur execution requete :" + requete);
				 }
	 }

	 public static ArrayList<Voiture> selectAllVoitures (String filtre){
			String requete ="";
			if (filtre.equals("")) {
				requete ="select * from voiture ;";
			}else {
				requete = "select * from voiture where immatriculation like '%"+filtre
						+"%' or modele_voiture like '%"+filtre+"%'or annee_modele like '%"+filtre+"%' ";
			}  
			ArrayList<Voiture>lesVoitures= new ArrayList<Voiture>();
			try {
				 uneBdd.seConnecter();
				  Statement unStat=uneBdd.getMaconnexion().createStatement();
				  ResultSet desRes = unStat.executeQuery(requete);
				  // on parcours les resultat pour construire ArrayList
				  while (desRes.next()) {
					  Voiture uneVoiture= new Voiture (
							  desRes.getInt("n_voiture"), desRes.getString("immatriculation"), desRes.getString("modele_voiture"),
					  desRes.getString("annee_modele")
					  );
					lesVoitures.add(uneVoiture);
				  }
				  unStat.close();
				  uneBdd.seDeconnecter();
			}
			catch (SQLException exp) {
				System.out.println("erreur execution requete: " + requete);
			}
			return lesVoitures;
		 }  

		public static Voiture selectWhereVoiture(String immatriculation, String modele_voiture, String annee_modele) {
			String requete = "select * from cours where immatriculation='"+immatriculation+"' and modele_voiture ='"+modele_voiture+
					"' and annee_modele ='"+annee_modele+"'  ";
		 Voiture uneVoiture = null;
		
				
				try {
					 uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  ResultSet desRes = unStat.executeQuery(requete);
					  // on parcours les resultat pour construire ArrayList
					  if (desRes.next()) {
						   uneVoiture = new Voiture (
								  desRes.getInt("n_voiture"), desRes.getString("immatriculation"), desRes.getString("modele_voiture"),
						  desRes.getString("annee_modele")
						  );		  
					  }
					  unStat.close();
					  uneBdd.seDeconnecter();
				}
				catch (SQLException exp) {
					System.out.println("erreur execution requete: " + requete);
				}
				return uneVoiture;
			}
			public static void deleteVoiture (int n_voiture) {
				String requete= "delete from voiture where n_voiture = "+n_voiture+";";
				 try {
					  uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  unStat.execute(requete);
					  unStat.close();
					  uneBdd.seDeconnecter();
					 }
					 catch(SQLException exp) {
						 System.out.println("erreur execution requete :" + requete);
					 }
			}
			public static void updateVoiture (Voiture uneVoiture) {
				String requete= "update voiture "
						+ "set n_voiture='"+uneVoiture.getN_voiture()+
						"', immatriculation='"+uneVoiture.getImmatriculation()+
						"',modele_voiture='"+uneVoiture.getImmatriculation()+
						"', annee_modele'"+uneVoiture.getAnnee_modele()+
						


						"' where idcours ="+uneVoiture.getN_voiture()+";";
				 try {
					  uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  unStat.execute(requete);
					  unStat.close();
					  uneBdd.seDeconnecter();
					 }
					 catch(SQLException exp) {
						 System.out.println("erreur execution requete :" + requete);
					 }
			}

	 /*****************************Gestion des type d'examen****************************/
			 public static void insertType_exam(Type_exam unType_exam) { 

					String requete ="insert into type_exam value (null,'"
							+unType_exam.getIdetypxam()+"','"+unType_exam.getType_exam()+"';";
					 try {
						  uneBdd.seConnecter();
						  Statement unStat=uneBdd.getMaconnexion().createStatement();
						  unStat.execute(requete);
						  unStat.close();
						  uneBdd.seDeconnecter();
						 }
						 catch(SQLException exp) {
							 System.out.println("erreur execution requete :" + requete);
						 }
						
			
			 }

		public static ArrayList<Type_exam> selectAllType_exam(String filtre){
			String requete ="";
			if (filtre.equals("")) {
				requete ="select * from type_exam ;";
			}else {
				requete = "select * from type_exam where idetypxam like '%"+filtre
						+"%' or type_exam like '"+filtre+"%'  ";
			}  
			ArrayList<Type_exam>lesType_exams = new ArrayList<Type_exam>();
			try {
				 uneBdd.seConnecter();
				  Statement unStat=uneBdd.getMaconnexion().createStatement();
				  ResultSet desRes = unStat.executeQuery(requete);
				  // on parcours les resultat pour construire ArrayList
				  while (desRes.next()) {
					  Type_exam unType_exam= new Type_exam (
							  desRes.getInt("idetypxam"), desRes.getString("type_exam")
					  );
					lesType_exams.add(unType_exam);
				  }
				  unStat.close();
				  uneBdd.seDeconnecter();
			}
			catch (SQLException exp) {
				System.out.println("erreur execution requete: " + requete);
			}
			return lesType_exams;
		 }  

		public static Type_exam selectWhereType_exam (String idetypxam, String type_exam) {
				String requete = "select * from Type_exam where idetypxam='"+idetypxam
						+"'and type_exam='"+type_exam+"' '";
			 Type_exam unType_exam = null;
				try {
					 uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  ResultSet desRes = unStat.executeQuery(requete);
					  // on parcours les resultat pour construire ArrayList
					  if (desRes.next()) {
						 unType_exam = new Type_exam (
								  desRes.getInt("idetypxam"), desRes.getString("type_exam")
								  );		  
					  }
					  unStat.close();
					  uneBdd.seDeconnecter();
				}
				catch (SQLException exp) {
					System.out.println("erreur execution requete: " + requete);
				}
				return unType_exam;
			}
			public static void deleteType_exam (int idetypxam) {
				String requete= "delete from type_exam where idetypxam = "+idetypxam+";";
				 try {
					  uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  unStat.execute(requete);
					  unStat.close();
					  uneBdd.seDeconnecter();
					 }
					 catch(SQLException exp) {
						 System.out.println("erreur execution requete :" + requete);
					 }
			}
			public static void updateType_exam(Type_exam unType_exam) {
				String requete= "update Type_exam"
						+ "set type_exam='"+unType_exam.getType_exam()+
						"' where idetypxam ="+unType_exam.getIdetypxam()+";";
				 try {
					  uneBdd.seConnecter();
					  Statement unStat=uneBdd.getMaconnexion().createStatement();
					  unStat.execute(requete);
					  unStat.close();
					  uneBdd.seDeconnecter();
					 }
					 catch(SQLException exp) {
						 System.out.println("erreur execution requete :" + requete);
					 }
			}
			
			 /*****************************Gestion des cours****************************/


	 public static void insertCours(Cours unCours) { 

			String requete ="insert into cours value (null,'"
					+unCours.getN_client()+"','" + unCours.getN_moniteur()
					+"','"+unCours.getN_voiture()+"','"+unCours.getDate_heure_debut()+"','"+unCours.getDate_heure_fin()+"');";
			 try {
				  uneBdd.seConnecter();
				  Statement unStat=uneBdd.getMaconnexion().createStatement();
				  unStat.execute(requete);
				  unStat.close();
				  uneBdd.seDeconnecter();
				 }
				 catch(SQLException exp) {
					 System.out.println("erreur execution requete :" + requete);
				 }
				
	
	 }

public static ArrayList<Cours> selectAllCours (String filtre){
	String requete ="";
	if (filtre.equals("")) {
		requete ="select * from cours ;";
	}else {
		requete = "select * from client where n_client like '%"+filtre
				+"%' or n_moniteur like '"+filtre+"%' or n_voiture like '%"+filtre
				+"%'or date_heure_debut like '%"+filtre 
				+"%'or date_heure_fin like '%"+filtre+"' ";
	}  
	ArrayList<Cours>lesCours = new ArrayList<Cours>();
	try {
		 uneBdd.seConnecter();
		  Statement unStat=uneBdd.getMaconnexion().createStatement();
		  ResultSet desRes = unStat.executeQuery(requete);
		  // on parcours les resultat pour construire ArrayList
		  while (desRes.next()) {
			  Cours unCours= new Cours (
					  desRes.getInt("id_cours"), desRes.getInt("n_client"), desRes.getInt("n_moniteur"),
			  desRes.getInt("n_voiture"), desRes.getString("date_heure_debut"),
			  desRes.getString("date_heure_fin")
			  );
			lesCours.add(unCours);
		  }
		  unStat.close();
		  uneBdd.seDeconnecter();
	}
	catch (SQLException exp) {
		System.out.println("erreur execution requete: " + requete);
	}
	return lesCours;
 }  

public static Cours selectWhereCours (String n_client, String n_moniteur, String n_voiture, String date_heure_debut, String date_heure_fin) {
		String requete = "select * from cours where n_client='"+n_client
				+"'and n_moniteur='"+n_moniteur+"' and n_voiture ='"+n_voiture+
				"' and date_heure_debut ='"+date_heure_debut+"' and date_heure_fin ='"+date_heure_fin+ "'  ";
	 Cours unCours = null;
		try {
			 uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  ResultSet desRes = unStat.executeQuery(requete);
			  // on parcours les resultat pour construire ArrayList
			  if (desRes.next()) {
				 unCours = new Cours (
						  desRes.getInt("id_cours"), desRes.getInt("n_client"), desRes.getInt("n_moniteur"),
						  desRes.getInt("n_voiture"), desRes.getString("date_heure_debut"),
						  desRes.getString("date_heure_fin")
						  );		  
			  }
			  unStat.close();
			  uneBdd.seDeconnecter();
		}
		catch (SQLException exp) {
			System.out.println("erreur execution requete: " + requete);
		}
		return unCours;
	}
	public static void deleteCours (int id_cours) {
		String requete= "delete from cours where id_cours = "+id_cours+";";
		 try {
			  uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  unStat.execute(requete);
			  unStat.close();
			  uneBdd.seDeconnecter();
			 }
			 catch(SQLException exp) {
				 System.out.println("erreur execution requete :" + requete);
			 }
	}
	public static void updateCours (Cours unCours) {
		String requete= "update cours "
				+ "set n_client='"+unCours.getN_client()+
				"', n_moniteur='"+unCours.getN_moniteur()+
				"',n_voiture='"+unCours.getN_voiture()+
				"',date_heure_debut'"+unCours.getDate_heure_debut()+
				"',date_heure_fin='"+unCours.getDate_heure_fin()+


				"' where idcours ="+unCours.getId_cours()+";";
		 try {
			  uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  unStat.execute(requete);
			  unStat.close();
			  uneBdd.seDeconnecter();
			 }
			 catch(SQLException exp) {
				 System.out.println("erreur execution requete :" + requete);
			 }
	}


	
	 /*****************************Gestion des examens****************************/
	
	public static void insertExamen(Examen unExamen) { 

		String requete ="insert into examen value (null,'"
				+unExamen.getN_client()+"','" + unExamen.getN_moniteur()
				+"','"+unExamen.getN_voiture()+"','"+unExamen.getType_exam()+"','"+unExamen.getDate_exam()+"');";
		 try {
			  uneBdd.seConnecter();
			  Statement unStat=uneBdd.getMaconnexion().createStatement();
			  unStat.execute(requete);
			  unStat.close();
			  uneBdd.seDeconnecter();
			 }
			 catch(SQLException exp) {
				 System.out.println("erreur execution requete :" + requete);
			 }
			

 }

public static ArrayList<Examen> selectAllExamen (String filtre){
String requete ="";
if (filtre.equals("")) {
	requete ="select * from examen ;";
}else {
	requete = "select * from examen where idexam like '%"+filtre
			+"%' or n_moniteur like '"+filtre+"%' or n_voiture like '%"+filtre
			+"%'or type_exam like '%"+filtre 
			+"%'or date_exam like '%"+filtre+"' ";
}  
ArrayList<Examen>lesExamens = new ArrayList<Examen>();
try {
	 uneBdd.seConnecter();
	  Statement unStat=uneBdd.getMaconnexion().createStatement();
	  ResultSet desRes = unStat.executeQuery(requete);
	  // on parcours les resultat pour construire ArrayList
	  while (desRes.next()) {
		  Examen unExamen= new Examen (
				  desRes.getInt("idexam"), desRes.getInt("n_client"), desRes.getInt("n_moniteur"),
		  desRes.getInt("n_voiture"), desRes.getString("type_exam"),
		  desRes.getString("date_exam")
		  );
		lesExamens.add(unExamen);
	  }
	  unStat.close();
	  uneBdd.seDeconnecter();
}
catch (SQLException exp) {
	System.out.println("erreur execution requete: " + requete);
}
return lesExamens;
}  

public static Examen selectWhereExamen (String n_client, String n_moniteur, String n_voiture, String type_exam, String date_exam) {
	String requete = "select * from examen where idexam='"+n_client
			+"'and n_moniteur='"+n_moniteur+"' and n_voiture ='"+n_voiture+
			"' and type_exam ='"+type_exam+"' and date_exam ='"+date_exam+ "'  ";
 Examen unExamen = null;
	try {
		 uneBdd.seConnecter();
		  Statement unStat=uneBdd.getMaconnexion().createStatement();
		  ResultSet desRes = unStat.executeQuery(requete);
		  // on parcours les resultat pour construire ArrayList
		  if (desRes.next()) {
			 unExamen = new Examen (
					  desRes.getInt("id_cours"), desRes.getInt("n_client"), desRes.getInt("n_moniteur"),
					  desRes.getInt("n_voiture"), desRes.getString("type_exam"),
					  desRes.getString("date_exam")
					  );		  
		  }
		  unStat.close();
		  uneBdd.seDeconnecter();
	}
	catch (SQLException exp) {
		System.out.println("erreur execution requete: " + requete);
	}
	return unExamen;
}
public static void deleteExamen (int idexam) {
	String requete= "delete from examen where idexam = "+idexam+";";
	 try {
		  uneBdd.seConnecter();
		  Statement unStat=uneBdd.getMaconnexion().createStatement();
		  unStat.execute(requete);
		  unStat.close();
		  uneBdd.seDeconnecter();
		 }
		 catch(SQLException exp) {
			 System.out.println("erreur execution requete :" + requete);
		 }
}
public static void updateExamen (Examen unExamen) {
	String requete= "update cours "
			+ "set n_client='"+unExamen.getN_client()+
			"', n_moniteur='"+unExamen.getN_moniteur()+
			"',n_voiture='"+unExamen.getN_voiture()+
			"',type_exam'"+unExamen.getType_exam()+
			"',date_exam='"+unExamen.getDate_exam()+


			"' where idexam ="+unExamen.getIdexam()+";";
	 try {
		  uneBdd.seConnecter();
		  Statement unStat=uneBdd.getMaconnexion().createStatement();
		  unStat.execute(requete);
		  unStat.close();
		  uneBdd.seDeconnecter();
		 }
		 catch(SQLException exp) {
			 System.out.println("erreur execution requete :" + requete);
		 }
}
}	
