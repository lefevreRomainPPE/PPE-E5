
DROP DATABASE IF EXISTS CASTELLANE;
 
CREATE DATABASE IF NOT EXISTS CASTELLANE;
USE CASTELLANE;
 
 
create table if not exists user (
  iduser int(3) not null auto_increment,
  nom varchar(50),
  prenom varchar(50),
  email varchar(50),
  mdp varchar(255),
  role enum("user", "admin"),
  primary key (iduser)
);
insert into USER values
  (null, 'Adam', 'Anes', 'a@gmail.com', '123', 'user');
insert into user values
  (null, 'Christina', 'Ibtissam', 'b@gmail.com', '456', 'admin');
 
CREATE TABLE IF NOT EXISTS CLIENT
 (
   N_CLIENT INT(10) auto_increment,
   NOM_CLIENT varchar(30) NOT NULL ,
   PRENOM_CLIENT varchar(50)  ,
   ADRESSE_CLIENT varchar(50) ,
   ADRESSE_MAIL varchar(50),
   DATE_DE_NAISSANCE DATE NULL,
   TELEPHONE varchar(20) ,
   DATE_INSCRIPTION DATE NULL,
   MODE_FACTURATION varchar(30) NULL,
   PRIMARY KEY (N_CLIENT)
 ) ;
 
CREATE TABLE IF NOT EXISTS MONITEUR
 (
   N_MONITEUR INT(10) auto_increment,
   NOM_MONITEUR varchar(30)  ,
   PRENOM_MONITEUR varchar(50)  ,
   ADRESSE_MONITEUR varchar(50) ,
   TELEPHONE varchar(20) ,
   NBLECON varchar(20),
   PRIMARY KEY (N_MONITEUR)
 ) ;
 
 
 
CREATE TABLE IF NOT EXISTS VOITURE
(
   N_VOITURE INT(10) AUTO_INCREMENT,
   IMMATRICULATION VARCHAR(40) NOT NULL,
   MODELE_VOITURE VARCHAR(50) NOT NULL,
   ANNEE_MODELE YEAR NULL,
   PRIMARY KEY (N_VOITURE)
);
 
 
CREATE TABLE IF NOT EXISTS COURS
 (
   ID_COURS INTEGER(2) NOT NULL auto_increment ,
   N_CLIENT INTEGER(10) NOT NULL  ,
   N_MONITEUR INTEGER(10) NOT NULL  ,
   N_VOITURE INTEGER(10) NOT NULL  ,
   DATE_HEURE_DEBUT DATETIME NULL  ,
   DATE_HEURE_FIN DATETIME NULL  
   , PRIMARY KEY (ID_COURS),
  FOREIGN KEY (N_CLIENT) REFERENCES CLIENT(N_CLIENT) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (N_MONITEUR) REFERENCES MONITEUR(N_MONITEUR) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (N_VOITURE) REFERENCES VOITURE(N_VOITURE) ON DELETE CASCADE ON UPDATE CASCADE
 ) ;
 
 
CREATE TABLE TYPE_EXAM(
    idetypxam int(3) not null auto_increment,
    type_exam varchar(50),
    primary key (idetypxam)
);
 
 CREATE TABLE EXAMEN (
    idexam int(3) not null auto_increment,
    N_CLIENT INTEGER(10) NOT NULL  ,
    N_MONITEUR INTEGER(10) NOT NULL  ,
    N_VOITURE INTEGER(10) NOT NULL  ,
    type_exam int(3) not null,
    date_exam date null,
    primary key (idexam),
    FOREIGN KEY (N_CLIENT) REFERENCES CLIENT(N_CLIENT) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (N_MONITEUR) REFERENCES MONITEUR(N_MONITEUR) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (N_VOITURE) REFERENCES VOITURE(N_VOITURE) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (type_exam) REFERENCES TYPE_EXAM(idetypxam)
);
 
insert into TYPE_EXAM values
  (null,'Permis');
insert into TYPE_EXAM values
  (null,'Code');
 
 
insert into VOITURE values (null,'AAA-555-BBB','Audi RS6','2023');
 
insert into CLIENT value (null,'Cader','Abdel','Les 2 tours','aaaa@gmeil.com','20010911','01010101101','20240101','espece');
 
insert into MONITEUR values (null,'Thomas','Dupont','24 rue du clos','06654615654','0')
